package com.glaucus.test;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.glaucus.base.BasePage;
import com.glaucus.pages.HomePage;
import com.glaucus.pages.LoginPage;
import com.glaucus.pages.NewOrder;
import com.glaucus.pages.SaleOrder;
import com.glaucus.utils.Utils;

public class TestFile {

	@BeforeTest
	public void browserLaunch() throws IOException {
		BasePage.initializeDriver();
		Utils.hitURL();
	}

	@Test
	public void Login() throws IOException {
		new LoginPage().getLogin();
	}

    @Test
    public void home() {
    	new HomePage().getHomePage();
    }
    
    @Test
    public void saleOrder() throws InterruptedException {
    	new SaleOrder().getSearch();
    }
    
    @Test
    public void zaddOrder() throws InterruptedException {
    	new NewOrder().getAddOrder();
    }

}
