package com.glaucus.utils;

import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.glaucus.base.BasePage;

public class Utils {

	public static WebDriver driver = BasePage.driver;

	public static Properties prop = BasePage.prop;

	static WebDriverWait wait = new WebDriverWait(driver, 15);

	public static void sendKeys(By locator, String abc) {

		wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).sendKeys(abc);

	}

	public static void click(By locator) {

		wait.until(ExpectedConditions.presenceOfElementLocated(locator)).click();

	}

	public static List<WebElement> path(By locator) {
		return wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));

	}

	public static void hitURL() {
		driver.get(prop.getProperty("url"));
	}

	public static void alert() {

		driver.switchTo().alert().dismiss();
	}

	public static void frame_In(By locator) {

		driver.switchTo().frame(driver.findElement(locator));
	}

	public static void frame_comeOut() {
		driver.switchTo().defaultContent();
	}
	
	public static void select(WebElement webelement, int intValue) {
		Select s = new Select(webelement);
		s.selectByIndex(intValue);
	}

}
