package com.glaucus.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.glaucus.base.BasePage;
import com.glaucus.utils.Utils;

public class NewOrder {
	
	WebDriver driver = BasePage.driver;
	
	
	By addOrder = By.xpath("//button[@id='SOAddNew' and @class='btn-first green-btn ng-scope']");
	By warehouse = By.id("SOAddDWh");
    By customer = By.xpath("//input[@id='customers_value']");
    By nand = By.xpath("(//div[text()='Nandkishor Verma'])[1]");
    By shippingAddress = By.xpath("(//div[@class='full_width modal-custom-col clearfix address-section ng-scope']/div//select)[1]");
    By billingAddress = By.xpath("(//div[@class='full_width modal-custom-col clearfix address-section ng-scope']/div//select)[2]");
    By SKU = By.cssSelector("#products_value");
    By feature_config = By.cssSelector("#clientprofileFeatureConfig");
    By switch_wms = By.xpath("//i[@data-original-title='Switch to WMS']");
	
	
	public void getAddOrder() throws InterruptedException {
		Utils.click(addOrder);
		
		Utils.select(driver.findElement(warehouse), 2);

	
	Utils.sendKeys(customer, "Nandkishor Verma");
	Utils.click(nand);
	Thread.sleep(2000);
	
	
	
	
     Utils.select(driver.findElement(shippingAddress), 1);
     Utils.select(driver.findElement(billingAddress), 1);
     
     Utils.sendKeys(SKU, "sku11"+Keys.ENTER);
     
     
     List<WebElement> path1 = Utils.path(new HomePage().click_order);
     for(WebElement w1 : path1) {
    	 if (w1.getText().equalsIgnoreCase("Settings")) {
    		 w1.click();
    	 }
     }
     
     
     List<WebElement> path2 = Utils.path(new HomePage().drp_dwn);
     for(WebElement w2 : path2 ) {
    	 
     
    	 if (w2.getText().equalsIgnoreCase("Client Profile")) {
			w2.click();
			break;
		}
     }
     
     
     
     Utils.click(feature_config);
     
     Utils.click(switch_wms);
     
     
	}
}
