package com.glaucus.pages;

import java.io.IOException; 

import org.openqa.selenium.By;

import com.glaucus.utils.Utils;

public class LoginPage {

	By email = By.id("loginEmail");
	By next_button = By.id("getClients");
	By password = By.id("loginPassword");
	By login_button = By.id("loginSubmit");
	By OMS = By.xpath("(//div[@class='screen-center ng-scope']/div)[2]");

	public void getLogin() throws IOException {


		Utils.sendKeys(email, "prakash");
		Utils.click(next_button);
		Utils.sendKeys(password, "abcd@1234");
		Utils.click(login_button);
		Utils.click(OMS);
	}

}
