package com.glaucus.pages;

import java.util.List;

import org.bouncycastle.jcajce.provider.symmetric.ARC4.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.glaucus.base.BasePage;
import com.glaucus.utils.Utils;

public class SaleOrder {
	WebDriver driver = BasePage.driver;

	By comanPath = By.xpath("//div[@class='col-xs-12 col-sm-6 col-md-2']/div/div/label");
	By drp1 = By.xpath("//select[@ng-model='filter.warehouse']");
	By drp2 = By.xpath("//select[@ng-model='filter.categoryId']");
	By drp3 = By.xpath("//select[@ng-model='filter.saleChannel']");
	By drp4 = By.xpath("//select[@ng-model='filter.tag']");
	By startDateIcon = By.xpath("(//div[@class='md-datepicker-expand-triangle ng-scope'])[1]");
	By selectStratDate = By.xpath(
			"/html[1]/body[1]/div[10]/div[2]/md-calendar[1]/div[1]/md-calendar-month[1]/div[1]/md-virtual-repeat-container[1]/div[1]/div[2]/table[1]/tbody[4]/tr[5]/td[1]/span[1]");

	By endDateIcon = By.xpath("(//div[@class='md-datepicker-expand-triangle ng-scope'])[2]");
	By selectEndDate = By.xpath(
			"/html[1]/body[1]/div[10]/div[2]/md-calendar[1]/div[1]/md-calendar-month[1]/div[1]/md-virtual-repeat-container[1]/div[1]/div[2]/table[1]/tbody[1]/tr[5]/td[1]/span[1]");

	By sugDrp = By.cssSelector(".angucomplete-title.ng-binding.ng-scope");
	By searchButton = By.id("SOSearch");

	
	
	
	public void getSearch() throws InterruptedException {
		List<WebElement> path1 = Utils.path(comanPath);

		for (WebElement webElement : path1) {

			if (webElement.getText().equalsIgnoreCase("Maven Order ID")) {

				driver.findElement(By.xpath("//input[@id='SONo']")).sendKeys("158210000TQ");
			} else if (webElement.getText().equalsIgnoreCase("Order Ref. No.")) {
				driver.findElement(By.cssSelector("input[placeholder='Ref. No.']")).sendKeys("55566");
			}

			else if (webElement.getText().equalsIgnoreCase("Warehouse")) {

				Utils.select(driver.findElement(drp1), 0);
			}

			else if (webElement.getText().equalsIgnoreCase("Search Customers")) {

				driver.findElement(By.id("customersfilter_value")).sendKeys("Nandkishor Verma" + Keys.ENTER);
				Thread.sleep(2000);

			}

			else if (webElement.getText().equalsIgnoreCase("Sales Channel")) {

				Utils.select(driver.findElement(drp3), 1);
			}

			else if (webElement.getText().equalsIgnoreCase("Start Date")) {

				Utils.click(startDateIcon);
				Utils.click(selectStratDate);

			} else if (webElement.getText().equalsIgnoreCase("End Date")) {

				Utils.click(endDateIcon);
				Thread.sleep(1000);
				Utils.click(selectEndDate);

			}

			else {
				System.out.println("");
			}
		}
		Utils.click(searchButton);
	}

}
