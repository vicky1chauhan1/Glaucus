package com.glaucus.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.glaucus.utils.Utils;

public class HomePage {
	By click_order = By.cssSelector(".menu-name-o");
	By drp_dwn = By.xpath("//a[@ng-class='{active: isActive(subMenu)}']");

	public void getHomePage() {
		List<WebElement> path1 = Utils.path(click_order);

		for (WebElement webElement : path1) {
			if (webElement.getText().equalsIgnoreCase("Orders")) {
				webElement.click();
				break;
			}
		}

		List<WebElement> path = Utils.path(drp_dwn);

		for (WebElement webElement : path) {
			if (webElement.getText().equalsIgnoreCase("Sale Order")) {
				webElement.click();
				break;
			}
		}
	}

}
